# KotlinPredicate
KotlinPredicate
