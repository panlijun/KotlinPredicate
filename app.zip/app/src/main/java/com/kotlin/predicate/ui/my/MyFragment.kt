package com.kotlin.predicate.ui.my

import android.os.Bundle
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.actions.getActionButton
import com.kotlin.predicate.R
import com.kotlin.predicate.app.base.BaseFragment
import com.kotlin.predicate.app.ext.initCommon
import com.kotlin.predicate.databinding.MyFragmentBinding

class MyFragment : BaseFragment<MyViewModel, MyFragmentBinding>() {

    var dialog: MaterialDialog? = null;

    companion object {
        fun newInstance() = MyFragment()
    }

    override fun initView(savedInstanceState: Bundle?) {

    }


}