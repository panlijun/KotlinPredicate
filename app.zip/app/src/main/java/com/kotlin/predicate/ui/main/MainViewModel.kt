package com.kotlin.predicate.ui.main

import com.mvvm.core.base.viewmodel.BaseViewModel

class MainViewModel : BaseViewModel() {
}