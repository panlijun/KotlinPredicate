package com.kotlin.predicate.data.model

data class HomeProject(var imgRes: Int = 0, var name: String = "")
