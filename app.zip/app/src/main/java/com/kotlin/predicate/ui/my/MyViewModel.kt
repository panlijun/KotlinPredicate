package com.kotlin.predicate.ui.my

import androidx.lifecycle.ViewModel
import com.mvvm.core.base.viewmodel.BaseViewModel

class MyViewModel : BaseViewModel() {
}