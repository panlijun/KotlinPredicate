package com.kotlin.predicate.ui.home

import androidx.lifecycle.ViewModel
import com.mvvm.core.base.viewmodel.BaseViewModel

class HomeViewModel : BaseViewModel() {
}