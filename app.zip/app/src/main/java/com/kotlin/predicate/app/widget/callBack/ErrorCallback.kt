
import com.kingja.loadsir.callback.Callback
import com.kotlin.predicate.R


class ErrorCallback : Callback() {

    override fun onCreateView(): Int {
        return R.layout.layout_error
    }

}