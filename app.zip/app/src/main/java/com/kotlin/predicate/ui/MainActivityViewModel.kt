package com.kotlin.predicate.ui

import com.mvvm.core.base.viewmodel.BaseViewModel

class MainActivityViewModel  : BaseViewModel() {
}