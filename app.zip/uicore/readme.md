# 第三方支持

##### material-dialogs

github：https://github.com/afollestad/material-dialogs
implementation 'com.afollestad.material-dialogs:core:3.3.0'

##### BasePopup

github：https://github.com/razerdp/BasePopup
implementation 'io.github.razerdp:BasePopup:3.2.0'

# From 表单输入

- FromInputItem 支持右边输入或者点击选择
- FromImageItem 支持图片选择

